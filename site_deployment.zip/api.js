import { db } from "./firebase-config.js";
import { collection, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

/**
 * Submit an order to Firestore
 * @param {Object} orderDetails - The order information
 * @returns {Promise<string>} - The ID of the created order document
 */
export async function submitOrder(orderData) {
    try {
        const docRef = await addDoc(collection(db, "orders"), {
            ...orderData,
            timestamp: serverTimestamp(),
            status: "pending"
        });
        console.log("Order written with ID: ", docRef.id);
        return docRef.id;
    } catch (e) {
        console.error("Error adding document: ", e);
        throw e;
    }
}
